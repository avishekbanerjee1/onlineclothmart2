import { Component, OnInit } from '@angular/core';  
import { AccountService } from '../account.service';  
import {FormControl,FormGroup,Validators} from '@angular/forms';  
import { Account } from '../account';  
@Component({  
  selector: 'app-add-account',  
  templateUrl: './add-account.component.html',  
  styleUrls: ['./add-account.component.css']  
})  
export class AddAccountComponent implements OnInit {  
  
  constructor(private accountservice:AccountService) { }  
  
  account : Account=new Account();  
  submitted = false;  
  
  ngOnInit() {  
    this.submitted=false;  
  }  
  
  accountsaveform=new FormGroup({  
    account_name:new FormControl('' , [Validators.required , Validators.minLength(5) ] ),  
    account_passwoprd:new FormControl('',[Validators.required,Validators.email]),  
    account_role:new FormControl()  
  });  
  
  saveAccount(saveAccouunt){  
    this.account=new Account();     
    this.account.account_name=this.AccountName.value;  
    this.account.account_password=this.AccountPassword.value;  
    this.account.account_role=this.AccountRole.value;  
    this.submitted = true;  
    this.save();  
  }  
  
    
  
  save() {  
    this.accountservice.createAccount(this.account)  
      .subscribe(data => console.log(data), error => console.log(error));  
    this.account = new Account();  
  }  
  
  get AccountName(){  
    return this.accountsaveform.get('account_name');  
  }  
  
  get AccountPassword(){  
    return this.accountsaveform.get('account_password');  
  }  
  
  get AccountRole(){  
    return this.accountsaveform.get('account_role');  
  }  
  
  addAccountForm(){  
    this.submitted=false;  
    this.accountsaveform.reset();  
  }  
}  