import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountListComponent } from './account-list/account-list.component';
import { AddAccountComponent } from './add-account/add-account.component';

const routes: Routes = [ 
{ path: '', redirectTo: 'view-account', pathMatch: 'full' },  
{ path: 'view-account', component: AccountListComponent },  
{ path: 'add-account', component: AddAccountComponent },  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
