import { Component, OnInit } from '@angular/core';  
import { AccountService } from '../account.service';  
import { Account } from '../account';  
import { Observable,Subject } from "rxjs";  
  
import {FormControl,FormGroup,Validators} from '@angular/forms';  
  
@Component({  
  selector: 'app-account-list',  
  templateUrl: './account-list.component.html',  
  styleUrls: ['./account-list.component.css']  
})  
export class AccountListComponent implements OnInit {  
  
 constructor(private accountservice:AccountService) { }  
  
  AccountsArray: any[] = [];  
  dtOptions: DataTables.Settings = {};  
  dtTrigger: Subject<any>= new Subject();  
  
  accounts: Observable<Account[]>;  
  account : Account=new Account();  
  deleteMessage=false;  
  accountlist:any;  
  isupdated = false;      
   
  
  ngOnInit() {  
    this.isupdated=false;  
    this.dtOptions = {  
      pageLength: 6,  
      stateSave:true,  
      lengthMenu:[[6, 16, 20, -1], [6, 16, 20, "All"]],  
      processing: true  
    };     
    this.accountservice.getAccountList().subscribe(data =>{  
    this.accounts =data;  
    this.dtTrigger.next();  
    })  
  }  
    
  deleteAccount(id: number) {  
    this.accountservice.deleteAccount(id)  
      .subscribe(  
        data => {  
          console.log(data);  
          this.deleteMessage=true;  
          this.accountservice.getAccountList().subscribe(data =>{  
            this.accounts =data  
            })  
        },  
        error => console.log(error));  
  }  
  
  updateAccount(id: number){  
    this.accountservice.getAccount(id)  
      .subscribe(  
        data => {  
          this.accountlist=data             
        },  
        error => console.log(error));  
  }  
  
  accountupdateform=new FormGroup({  
    account_id:new FormControl(),  
    account_name:new FormControl(),  
    account_password:new FormControl(),  
    account_role:new FormControl()  
  });  
  
  updateStu(updstu){  
    this.account=new Account();   
   this.account.account_id=this.AccountId.value;  
   this.account.account_name=this.AccountName.value;  
   this.account.account_email=this.AccountPassword.value;  
   this.account.account_role=this.AccountRole.value;  
   console.log(this.AccountRole.value);  
     
  
   this.accountservice.updateAccount(this.account.account_id,this.account).subscribe(  
    data => {       
      this.isupdated=true;  
      this.accountservice.getAccountList().subscribe(data =>{  
        this.accounts =data  
        })  
    },  
    error => console.log(error));  
  }  
  
  get AccountName(){  
    return this.accountupdateform.get('account_name');  
  }  
  
  get AccountPassword(){  
    return this.accountupdateform.get('account_password');  
  }  
  
  get AccountRole(){  
    return this.accountupdateform.get('account_role');  
  }  
  
  get AccountId(){  
    return this.accountupdateform.get('account_id');  
  }  
  
  changeisUpdate(){  
    this.isupdated=false;  
  }  
}  