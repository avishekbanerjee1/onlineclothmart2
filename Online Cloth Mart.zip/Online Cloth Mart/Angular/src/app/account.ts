export class Account {  
  
    account_id:number;  
    account_name:String;  
    account_email:String;  
    account_branch:String;  
  account_password: any;
  account_role: any;
}  
