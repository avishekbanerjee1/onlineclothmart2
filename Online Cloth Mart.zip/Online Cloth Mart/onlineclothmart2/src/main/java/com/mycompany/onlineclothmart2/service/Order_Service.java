package com.mycompany.onlineclothmart2.service;

import java.util.List;  
import com.mycompany.onlineclothmart2.model.Order;  
  
public interface Order_Service {  
  
      
    public boolean saveOrder(Order order);  
    public List<Order> getOrders();  
    public boolean deleteOrder(Order order);  
    public List<Order> getOrderByID(Order order);  
    public boolean updateOrder(Order order);  
}  