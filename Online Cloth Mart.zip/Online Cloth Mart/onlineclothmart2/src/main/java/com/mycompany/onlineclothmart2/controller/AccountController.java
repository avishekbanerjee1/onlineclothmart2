package com.mycompany.onlineclothmart2.controller;

import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.CrossOrigin;  
import org.springframework.web.bind.annotation.DeleteMapping;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
import com.mycompany.onlineclothmart2.model.Account;  
import com.mycompany.onlineclothmart2.service.Account_Service;  
  
@RestController  
@CrossOrigin(origins="http://localhost:4200")  
@RequestMapping(value="/api")  
public class AccountController {  
      
    @Autowired  
    private Account_Service accountservice;  
      
    @PostMapping("save-account")  
    public boolean saveAccount(@RequestBody Account account) {  
         return accountservice.saveAccount(account);  
          
    }  
      
    @GetMapping("accounts-list")  
    public List<Account> allaccounts() {  
         return accountservice.getAccounts();  
          
    }  
      
    @DeleteMapping("delete-account/{account_id}")  
    public boolean deleteAccount(@PathVariable("account_id") int account_id,Account account) {  
        account.setAccount_id(account_id);  
        return accountservice.deleteAccount(account);  
    }  
  
    @GetMapping("account/{account_id}")  
    public List<Account> allAccountByID(@PathVariable("account_id") int account_id,Account account) {  
         account.setAccount_id(account_id);  
         return accountservice.getAccountByID(account);  
          
    }  
      
    @PostMapping("update-account/{account_id}")  
    public boolean updateAccount(@RequestBody Account account,@PathVariable("account_id") int account_id) {  
        account.setAccount_id(account_id);  
        return accountservice.updateAccount(account);  
    }  
}  