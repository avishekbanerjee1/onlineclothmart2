package com.mycompany.onlineclothmart2.controller;

import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.CrossOrigin;  
import org.springframework.web.bind.annotation.DeleteMapping;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
import com.mycompany.onlineclothmart2.model.Order;  
import com.mycompany.onlineclothmart2.service.Order_Service;  
  
@RestController  
@CrossOrigin(origins="http://localhost:4200")  
@RequestMapping(value="/api")  
public class OrderController {  
      
    @Autowired  
    private Order_Service orderservice;  
      
    @PostMapping("save-order")  
    public boolean saveOrder(@RequestBody Order order) {  
         return orderservice.saveOrder(order);  
          
    }  
      
    @GetMapping("orders-list")  
    public List<Order> allorders() {  
         return orderservice.getOrders();  
          
    }  
      
    @DeleteMapping("delete-order/{order_id}")  
    public boolean deleteOrder(@PathVariable("order_id") int order_id,Order order) {  
        order.setOrder_id(order_id);  
        return orderservice.deleteOrder(order);  
    }  
  
    @GetMapping("order/{order_id}")  
    public List<Order> allorderByID(@PathVariable("order_id") int order_id,Order order) {  
         order.setOrder_id(order_id);  
         return orderservice.getOrderByID(order);  
          
    }  
      
    @PostMapping("update-order/{order_id}")  
    public boolean updateOrder(@RequestBody Order order,@PathVariable("order_id") int order_id) {  
        order.setOrder_id(order_id);  
        return orderservice.updateOrder(order);  
    }  
}  