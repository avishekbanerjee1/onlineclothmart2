package com.mycompany.onlineclothmart2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Onlineclothmart2Application {

	public static void main(String[] args) {
		SpringApplication.run(Onlineclothmart2Application.class, args);
	}

}
