package com.mycompany.onlineclothmart2.dao;



import java.util.List;  


import com.mycompany.onlineclothmart2.model.Order;
  
public interface Order_DAO {  
  
    public boolean saveOrder(Order order);  
    public List<Order> getOrders();  
    public boolean deleteOrder(Order order);  
    public List<Order> getOrderByID(Order order);  
    public boolean updateOrder(Order order);  
}  