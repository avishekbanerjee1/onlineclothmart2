package com.mycompany.onlineclothmart2.dao;



import java.util.List;  


import com.mycompany.onlineclothmart2.model.Account;  
  
public interface Account_DAO {  
  
    public boolean saveAccount(Account account);  
    public List<Account> getAccounts();  
    public boolean deleteAccount(Account account);  
    public List<Account> getAccountByID(Account account);  
    public boolean updateAccount(Account account);  
}  