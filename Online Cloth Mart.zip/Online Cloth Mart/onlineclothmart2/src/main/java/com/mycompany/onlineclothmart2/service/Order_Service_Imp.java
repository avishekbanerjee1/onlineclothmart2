package com.mycompany.onlineclothmart2.service;

import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;  
import org.springframework.transaction.annotation.Transactional;  
import com.mycompany.onlineclothmart2.dao.Order_DAO;  
import com.mycompany.onlineclothmart2.model.Order;  
  
@Service  
@Transactional  
public class Order_Service_Imp implements Order_Service {  
   
    @Autowired  
    private Order_DAO orderdao;  
      
    @Override  
    public boolean saveOrder(Order order) {  
        return orderdao.saveOrder(order);  
    }  
  
    @Override  
    public List<Order> getOrders() {  
        return orderdao.getOrders();  
    }  
  
    @Override  
    public boolean deleteOrder(Order order) {  
        return orderdao.deleteOrder(order);  
    }  
  
    @Override  
    public List<Order> getOrderByID(Order order) {  
        return orderdao.getOrderByID(order);  
    }  
  
    @Override  
    public boolean updateOrder(Order order) {  
        return orderdao.updateOrder(order);  
    }  
  
}  