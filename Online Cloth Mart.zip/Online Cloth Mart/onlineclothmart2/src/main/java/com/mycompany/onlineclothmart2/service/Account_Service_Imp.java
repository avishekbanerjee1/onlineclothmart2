package com.mycompany.onlineclothmart2.service;

import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;  
import org.springframework.transaction.annotation.Transactional;  
import com.mycompany.onlineclothmart2.dao.Account_DAO;  
import com.mycompany.onlineclothmart2.model.Account;  
  
@Service  
@Transactional  
public class Account_Service_Imp implements Account_Service {  
   
    @Autowired  
    private Account_DAO accountdao;  
      
    @Override  
    public boolean saveAccount(Account account) {  
        return accountdao.saveAccount(account);  
    }  
  
    @Override  
    public List<Account> getAccounts() {  
        return accountdao.getAccounts();  
    }  
  
    @Override  
    public boolean deleteAccount(Account account) {  
        return accountdao.deleteAccount(account);  
    }  
  
    @Override  
    public List<Account> getAccountByID(Account account) {  
        return accountdao.getAccountByID(account);  
    }  
  
    @Override  
    public boolean updateAccount(Account account) {  
        return accountdao.updateAccount(account);  
    }  
  
}  