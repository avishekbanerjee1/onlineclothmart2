package com.mycompany.onlineclothmart2.model;

import java.sql.Date;

import javax.persistence.Entity;  
import javax.persistence.GeneratedValue;  
import javax.persistence.GenerationType;  
import javax.persistence.Id;  
import javax.persistence.Table;  
  
@Entity  
@Table(name="orders")  
public class Order {  
    @Id  
    @GeneratedValue(strategy=GenerationType.IDENTITY)  
    private int order_id;  
    private Date order_date;  
    private int order_Num;  
    private double order_amount;  
    private String customer_name;
    private String customer_address;
    private String customer_email;
    
	public String getCustomer_email() {
		return customer_email;
	}
	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	
	public Date getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}
	public int getOrder_Num() {
		return order_Num;
	}
	public void setOrder_Num(int order_Num) {
		this.order_Num = order_Num;
	}
	
	public double getOrder_amount() {
		return order_amount;
	}
	public void setOrder_amount(double order_amount) {
		this.order_amount = order_amount;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomer_address() {
		return customer_address;
	}
	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}
    
    
    
      
}  