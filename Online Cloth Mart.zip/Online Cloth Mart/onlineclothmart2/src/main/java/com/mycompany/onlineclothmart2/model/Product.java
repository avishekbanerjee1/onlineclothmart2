package com.mycompany.onlineclothmart2.model;

import javax.persistence.Entity;  
import javax.persistence.GeneratedValue;  
import javax.persistence.GenerationType;  
import javax.persistence.Id;  
import javax.persistence.Table;  
  
@Entity  
@Table(name="products")  
public class Product {  
    @Id  
    @GeneratedValue(strategy=GenerationType.IDENTITY)  
    private int product_id;  
    private String product_name;  
    private double product_price;  
    private int product_size;
    private String product_create_date;
    
    
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getProduct_price() {
		return product_price;
	}
	public void setProduct_price(double product_price) {
		this.product_price = product_price;
	}
	public int getProduct_size() {
		return product_size;
	}
	public void setProduct_size(int product_size) {
		this.product_size = product_size;
	}
	public String getProduct_create_date() {
		return product_create_date;
	}
	public void setProduct_create_date(String product_create_date) {
		this.product_create_date = product_create_date;
	}
    
    
 
  
      
}  